({
    doInit: function (component, event, helper) {
        helper.getTree(component, helper);
    }
})