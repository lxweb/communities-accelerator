({
	onInit : function(component, event, helper) {
	}
})